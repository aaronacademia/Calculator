/* Aaron Academia
 * August 26, 2022
 * Library of math methods
 */
public class Calculate {
	//returns the square of the input
	public static int square(int number) {
		int answer=number*number;
		return answer;
	}
	public static double square(double number) {
		double answer=number*number;
		return answer;
	}
	public static int cube(int number) {
	//returns the cube of the input
		int answer=square(number)*number;
		return answer;
	}
	public static double average(double num1, double num2) {
	//returns the average of the two inputs
		double answer=(num1+num2)/2;
		return answer;
	}
	public static double average(double num1, double num2, double num3) {
	//returns the average of the three inputs
		double answer=(num1+num2+num3)/3;
		return answer;
	}
	public static double toDegrees(double rad) {
	//returns the angle in radians into degrees
		double answer=rad*(180/3.14159);
		return answer;
	}
	public static double toRadians(double deg) {
	//returns the angle in degrees to radians
		double answer=deg*(3.14159/180);
		return answer;
	}
	public static double discriminant(double num1, double num2, double num3) {
	//returns the discriminant of the inputs (b^2-4ac)
		double answer=square(num2) - 4*num1*num3;
		return answer;
	}
	public static String toImproperFrac(int num1, int num2, int num3) {
	//returns the mixed number converted into an improper fraction
		int mixedNum=num1*num3+num2;
		return mixedNum+"/"+num3;
	}
	public static String toMixedNum(int numer, int denom) {
	//returns the improper fraction converted into a mixed number
		int num1=numer/denom;
		int num2=numer%denom;
		return num1+"_"+num2+"/"+denom;
	}
	public static String foil(int num1, int num2, int num3, int num4, String var) {
	//returns the 5 inputs and foils it into the form ax^2+bx+c
		int middlenum=num1*num4+num2*num3;
		return num1*num3+var+"^2"+" + "+middlenum+var+" + "+num4*num2;
	}
	/*
	 * END OF PART 1
	 */
	public static boolean isDivisibleBy(int num1, int num2) {
	//determines if a number is divisible by another and returns a true or false statement
		if (num2==0) throw new IllegalArgumentException("cannot divide by 0");
		boolean answer=num1%num2==0;
		return answer;
	}
	public static double absValue(double num) {
	//returns the absolute value of the input
		if (num>=0) {
			return num;
		}else {
			return num*-1;
		}
	}
	public static double max(double num1, double num2) {
	//returns the larger value of the two inputs
		if (num1>=num2) {
			return num1;
		}else {
			return num2;
		}
	}
	public static double max(double num1, double num2, double num3) {
	//returns the larger value of the three inputs
		if (num1>=num2&&num1>=num3) {
			return num1;
		}else if (num2>=num1&&num2>=num3) {
			return num2;
		}else {
			return num3;
		}
	}
	public static int min(int num1, int num2) {
	//returns the smaller value of the two inputs
		if (num1<=num2) {
			return num1;
		}else {
			return num2;
		}
	}
	public static double round2(double num) {
	//rounds the input to two decimal places
		if (num>=0) {
			double first=(num*1000+5)/10;
			int second=(int)first;
			double answer=second;
			return answer/100;
		}else {
			double first=(num*1000-5)/10;
			int second=(int)first;
			double answer=second;
			return answer/100;
		}
	}
	/*
	 * END OF PART 2
	 */
	public static double exponent(double num, int exp) {
	//raises the input by the power of a value
		if (exp<0) throw new IllegalArgumentException("exponent cannot be negative");
		if (num==0 && exp==0) throw new IllegalArgumentException("zero to the power of zero is undefined");
			double answer=1;
			for (int i=1; i<=exp; i++) {
				answer*=num;
			}
			return answer;
	}
	public static int factorial(int num) {
	//returns the factorial of the input
		if (num<0) throw new IllegalArgumentException("cannot find the factorial of a negative number");
			int product=1;
			int factor=2;
			while (factor<=num) {
			product*=factor;
			factor++;
		}
		return product;
	}
	public static boolean isPrime(int num) {
	//determines if a number is a prime number and returns a true or false statement
		boolean answer=false;
		for (int num2=num-1; num2>1; num2--) {
			answer=isDivisibleBy(num, num2);
			if (answer==true) {
				answer=false;
			}else {
				answer=true;
			}
		}return answer;
	}
	public static int gcf(int num1, int num2) {
	//returns the greatest common factor of the two inputs and returns and integer
		int answer=1;
		if (num1<0) {
			num1*=-1;
		}if (num2<0) {
			num2*=-1;
		}if (num1==0) {
			return num2;
		}if (num2==0) {
			return num1;
		}
		for (int i=1; i<=num1&&i<=num2; i++) {
			boolean first=isDivisibleBy(num1, i);
			boolean second=isDivisibleBy(num2, i);
			if (first==true&&second==true) {
				answer=i;
			}
		}
		return answer;
	}
	public static double sqrt(double num) {
	//returns the square root of a double and returns a double
		if (num<0) throw new IllegalArgumentException("cannot find the square root of a negative number");
			double est = num/2;
			double answer=0;
			while (absValue(square(est)-num)>=0.005) {
				answer = 0.5*(num/est+est);
				est=answer;
			}
			return Calculate.round2(answer);
	}
	/*
	 * END OF PART 3
	 */
	public static double min(double num1, double num2) {
		//returns the smaller value of the two inputs
			if (num1<=num2) {
				return num1;
			}else {
				return num2;
			}
		}
	public static String quadForm(int a, int b, int c) {
	//returns the real roots (if any) of a quadratic formula, using the inputs as coefficients
		double discriminant = discriminant(a, b, c);
			if (discriminant > 0) {
				double answer1 = (b*-1) + (sqrt(discriminant));
				double firstRoot = round2(answer1/(2*a));
				double answer2 = (b*-1) - (sqrt(discriminant));
				double secondRoot = round2(answer2/(2*a));
				return min(firstRoot, secondRoot) + " and " + max(firstRoot, secondRoot);
			} if (discriminant == 0) {
				double num1 = a;
				double num2 = b;
				double answer = round2((num2*-1)/(2*num1));
				return "" + answer;
			}
			return "no real roots";
	}
}