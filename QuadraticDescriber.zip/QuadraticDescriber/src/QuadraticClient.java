/* Aaron Academia
 * 9/23/22
 * Client code for Calculate Part 5
 */
import java.util.*;
public class QuadraticClient {

	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);
		//Greeting
		System.out.println("Welcome to the Quadratic Describer\nProvide values for coefficients a, b, and c");
		//loop (while)
		String answer = "";
		while (!answer.equals("quit")) {
			//get input from user
			System.out.print("\na: ");
				double a = userInput.nextDouble();
			System.out.print("b: ");
				double b = userInput.nextDouble();
			System.out.print("c: ");
				double c = userInput.nextDouble();
			System.out.println("\nDescription of the graph of:\n" + "y = " + a + " x^2 + " + b + " x + " + c);
			//call quadrDescriber() to analyze the function
			String description = Quadratic.quadrDescriber(a, b, c);
			//print the results
			System.out.println(description);
			//ask --go again?
			System.out.println("\nDo you want to keep going? (Type \"quit\" to end)");
			//get answer
			answer = userInput.next();
		}
		//closes scanner
		userInput.close();
	}
}