/* Aaron Academia
 * 9/23/22
 * Methods required to analyze a quadratic function
 */
public class Quadratic {
	public static String quadrDescriber(double a, double b, double c) {
	//describes the quadratic function
		if (a==0)throw new IllegalArgumentException("input for \"a\" value cannot be zero because it is not a quadratic function");
		String answer="";
		String direction, vertex, xInt; 
		Double yAxis, yInt;
		if (a < 0) {
			direction ="Down";
		}else {
			direction = "Up";}
		yAxis = (b*-1)/(2*a);
		vertex = "(" + round2(yAxis) + ", " + round2(a*(square(yAxis))+(b*yAxis)+c) + ")";
		xInt = quadForm(a, b, c);
		yInt = c;
		answer = "\nOpens: "+direction+"\nAxis of Symmetry: "+round2(yAxis)+"\nVertex: "+vertex+"\nx-intercept(s): "+xInt+"\ny-intercept: "+yInt;
		return answer;
	}
	//quadForm()
	public static String quadForm(double a, double b, double c) {
		//returns the real roots (if any) of a quadratic formula, using the inputs as coefficients
			double discriminant = discriminant(a, b, c);
				if (discriminant > 0) {
					double answer1 = (b*-1) + (sqrt(discriminant));
					double firstRoot = round2(answer1/(2*a));
					double answer2 = (b*-1) - (sqrt(discriminant));
					double secondRoot = round2(answer2/(2*a));
					return min(firstRoot, secondRoot) + " and " + max(firstRoot, secondRoot);
				} if (discriminant == 0) {
					double num1 = a;
					double num2 = b;
					double answer = round2((num2*-1)/(2*num1));
					return "" + answer;
				}
				return "None";
		}
	//sqrt()
	public static double sqrt(double num) {
		//returns the square root of a double and returns a double
			if (num<0) throw new IllegalArgumentException("cannot find the square root of a negative number");
				double est = num/2;
				double answer=0;
				while (absValue(square(est)-num)>=0.005) {
					answer = 0.5*(num/est+est);
					est=answer;
				}
				return round2(answer);
		}
	//discriminant()
	public static double discriminant(double num1, double num2, double num3) {
		//returns the discriminant of the inputs (b^2-4ac)
			double answer=square(num2) - 4*num1*num3;
			return answer;
		}
	//absValue()
	public static double absValue(double num) {
		//returns the absolute value of the input
			if (num>=0) {
				return num;
			}else {
				return num*-1;
			}
		}
	//square()
	public static double square(double number) {
		double answer=number*number;
		return answer;
	}
	//round2()
	public static double round2(double num) {
		//rounds the input to two decimal places
			if (num>=0) {
				double first=(num*1000+5)/10;
				int second=(int)first;
				double answer=second;
				return answer/100;
			}else {
				double first=(num*1000-5)/10;
				int second=(int)first;
				double answer=second;
				return answer/100;
			}
		}
	//max()
	public static double max(double num1, double num2) {
		//returns the larger value of the two inputs
			if (num1>=num2) {
				return num1;
			}else {
				return num2;
			}
		}
	//min()
	public static double min(double num1, double num2) {
		//returns the smaller value of the two inputs
			if (num1<=num2) {
				return num1;
			}else {
				return num2;
			}
		}
}
